/** Update status as reported by the AndySU host. */
export interface Status {
    state: 'idle' | 'checking' | 'up_to_date' | 'deferred' | 'available' | 'downloading' | 'staged' | 'applying' | 'shell_update' | 'error';
    release?: string;
    hot_only?: boolean;
    mandatory?: boolean;
    download_bytes?: number;
    code?: string;
    message?: string;
    [k: string]: unknown;
}
export interface HostInfo {
    /** False when the app is not running under an AndySU host (e.g. a debug build). */
    present: boolean;
    apiLevel?: number;
    version?: string;
    isFactory?: boolean;
    slotDir?: string;
}
/** Information about the running payload. */
export declare function info(): Promise<HostInfo>;
/** The updater's current status. */
export declare function status(): Promise<Status>;
/** Check now (download and stage according to the configured mode). */
export declare function checkNow(): void;
/** Apply a staged update now (live if possible, otherwise by restarting). */
export declare function applyNow(): void;
/** Restart into the newest staged or committed payload. */
export declare function restartNow(): void;
export type ApplyPolicy = 'live' | 'restart' | 'next_start';
/**
 * How staged updates apply on this install: swap live (the default), restart the app, or wait for
 * the next start. Pass null to return to the policy configured in andysu.toml.
 */
export declare function setApplyPolicy(policy: ApplyPolicy | null): void;
export declare function applyPolicy(): Promise<ApplyPolicy>;
/** Commit this payload generation (call once the app is known to work). */
export declare function markHealthy(): void;
/** Listen for status changes. Returns an unsubscribe function. */
export declare function onStatus(cb: (s: Status) => void): () => void;
